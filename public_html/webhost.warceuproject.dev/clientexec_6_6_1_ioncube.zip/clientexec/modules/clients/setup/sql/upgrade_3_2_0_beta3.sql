# ---------------------------------------------------------
# NEW PERMISSIONS FOR EDITTING CLIENT PAYMENT METHODS
# ---------------------------------------------------------

INSERT INTO `permissions` (`subject_id`, `is_group`, `permission`, `target_id`) VALUES (1, 1, 'clients_edit_payment_type', 0);
INSERT INTO `permissions` (`subject_id`, `is_group`, `permission`, `target_id`) VALUES (3, 1, 'clients_edit_payment_type', 0);
INSERT INTO `permissions` (`subject_id`, `is_group`, `permission`, `target_id`) VALUES (4, 1, 'clients_edit_payment_type', 0);
INSERT INTO `permissions` (`subject_id`, `is_group`, `permission`, `target_id`) VALUES (5, 1, 'clients_edit_payment_type', 0);