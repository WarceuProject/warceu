# ----------------------------------------------------
# RENAME ALTUSEREMAIL SUPPORT COLUMN TO BE CONSISTENT
# ----------------------------------------------------
ALTER TABLE  `altuseremail` ADD  `sendsupport` TINYINT( 4 )