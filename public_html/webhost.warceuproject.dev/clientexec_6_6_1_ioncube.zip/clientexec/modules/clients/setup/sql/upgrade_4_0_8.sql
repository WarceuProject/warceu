ALTER TABLE `domains` CHANGE `custom_price` `custom_price` FLOAT(23,2) NOT NULL DEFAULT '0.00';
ALTER TABLE `userPackage` CHANGE `customPrice` `customPrice` FLOAT(23,2) NOT NULL DEFAULT '0.00';