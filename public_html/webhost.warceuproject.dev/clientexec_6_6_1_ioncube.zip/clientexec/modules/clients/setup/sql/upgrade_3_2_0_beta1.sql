# ---------------------------------------------------------
# NEW CUSTOM FIELD FOR VAT STORAGE
# ---------------------------------------------------------
INSERT INTO `customuserfields` VALUES (NULL, 'VAT Number', 47, 0, 2, 0, 20, 11, 1, 0, 1, 1, '');