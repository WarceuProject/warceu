# drop table users_domains
DROP TABLE IF EXISTS users_domains;