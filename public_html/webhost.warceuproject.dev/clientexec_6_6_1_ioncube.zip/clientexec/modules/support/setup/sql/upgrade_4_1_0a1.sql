DELETE FROM `permissions` where permission = 'support_view_all_closed_tickets';
DELETE FROM `permissions` where permission = 'support_show_departments';
DELETE FROM `permissions` where permission = 'support_show_escalations';
DELETE FROM `permissions` where permission = 'support_show_emailroutings';