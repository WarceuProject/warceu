CREATE TABLE `troubleticket_type_customfields` (
    `tickettype_id` INT NOT NULL ,
    `custom_id` INT NOT NULL
) DEFAULT CHARACTER SET utf8, ENGINE = [MYISAM];
