# ---------------------------------------------------------
# NEW PERMISSIONS
# ---------------------------------------------------------

INSERT INTO `permissions` (`subject_id`, `is_group`, `permission`, `target_id`) VALUES (1, 1, 'home_view_recommend_us', 0);
